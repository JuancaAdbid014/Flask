class BaseConfig:
    SECRET_KEY = 'SUPER SECRETO'
